# BigTalker2
Have you ever wanted a talking house? Now you can! With the Big Talker SmartApp!

When SmartThings is paired with a compatible audio device (such as a Sonos, Ubi, LANnouncer, VLCThing, AskAlexa, etc) and Big Talker SmartApp, your house can say what you want it to say when events occur.

Please review the documentation at http://thingsthataresmart.wiki/index.php?title=BigTalker

